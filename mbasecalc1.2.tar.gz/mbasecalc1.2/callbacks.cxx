#include "mbasecalc.h"
#include "callbacks.h"
#include "fmt.h"

static Fl_Color     mode_bg;
static Fl_Color     mode_fg;
static Fl_Color     mode_sel_bg;
static Fl_Color     mode_sel_fg;

static int  s_value=0;
static int  s_accum=0;
static int  s_last_op=OPR_ADD;
static int  s_reset=0;
static unsigned int s_unsigned=1;
static Fl_Window *shortcut_window=NULL;

static const char *shortcut_text=
"\n"
"mbasecalc 1.1 Keyboard shortcuts\n\n"
" Shortcuts   Key     Description\n"
"==========  ======= ===============================\n"
" Shift+h     HEX     Hexadecimal mode\n"
" Shift+d     DEC     Decimal mode (default)\n"
" Shift+o     OCT     Octal mode\n"
" Shift+b     BIN     Binary mode\n"
" Shift+u     U       Unsigned mode (default)\n"
" Shift+s     S       Signed mode\n"
" Ctrl+d      CD      Delete (same as Backspace)\n"
" Ctrl+e      CE      Erase All (from screen)\n"
" Ctrl+A      CA      Clear All\n"
" +-*/       +-*      Add, substract and divide respectively\n"
" %           %       Modulus\n"
" |           |       Bitwise OR\n"
" &           &       Bitwise AND\n"
" ^           ^       Bitwise XOR\n"
" ~           ~       Bitwise NOT (One's complement)\n"
" >           >>      Right Shift\n"
" <           <<      Left Shift\n"
" =           Enter   commit the operation";

void makeColors(void)
{
    mode_bg=hex_button->color();
    mode_fg=hex_button->labelcolor();

    mode_sel_bg=fl_color_cube(SELECTED_BG_RED,SELECTED_BG_GREEN,
                              SELECTED_BG_BLUE);
    mode_sel_fg=fl_color_cube(SELECTED_FG_RED,SELECTED_FG_GREEN,
                              SELECTED_FG_BLUE);
}

/* callback from About popup menu item */
void aboutCb(void)
{
    about_window->show();
}

void shortcutCb(void)
{
    if (!shortcut_window)
    {
        shortcut_window=new Fl_Window(480,360,"mbasecalc Shortcuts");
        shortcut_window->color(FL_WHITE);
        Fl_Box
            *b=new Fl_Box(20,0,360,360,shortcut_text);
        b->labelfont(4);
        b->labelsize(12);
        b->align(FL_ALIGN_LEFT|FL_ALIGN_INSIDE|FL_ALIGN_TOP);
        shortcut_window->resizable(shortcut_window); 
        shortcut_window->end();
    }
    shortcut_window->hotspot(shortcut_window);
    shortcut_window->set_non_modal();
    shortcut_window->show();
}



/* call back from Help in popup menu */
void hexButtons(int w)
{
    if (w == 0)
    {
        a_button->deactivate();
        b_button->deactivate();
        c_button->deactivate();
        d_button->deactivate();
        e_button->deactivate();
        f_button->deactivate();
    }
    else
    {
        a_button->activate();
        b_button->activate();
        c_button->activate();
        d_button->activate();
        e_button->activate();
        f_button->activate();
    }
}

void activateDeactivateButtons(int buttons,int do_what)
{
    if (buttons == HEX_BUTTONS)
    {
        if (do_what == ACTIVATE)
        {
            a_button->activate();
            b_button->activate();
            c_button->activate();
            d_button->activate();
            e_button->activate();
            f_button->activate();
        }
        else
        {
            a_button->deactivate();
            b_button->deactivate();
            c_button->deactivate();
            d_button->deactivate();
            e_button->deactivate();
            f_button->deactivate();
        }
    }

    if (buttons == NUM_BUTTONS)
    {
        if (do_what == ACTIVATE)
        {
            two_button->activate();
            three_button->activate();
            four_button->activate();
            five_button->activate();
            six_button->activate();
            seven_button->activate();
            eight_button->activate();
            nine_button->activate();
        }
        else
        {
            two_button->deactivate();
            three_button->deactivate();
            four_button->deactivate();
            five_button->deactivate();
            six_button->deactivate();
            seven_button->deactivate();
            eight_button->deactivate();
            nine_button->deactivate();
        }
    }
}

static void highlishtModeButton(int base)
{
    switch (base)
    {
        case 10:
        {
            activateDeactivateButtons(HEX_BUTTONS,DEACTIVATE);
            activateDeactivateButtons(NUM_BUTTONS,ACTIVATE);

            dec_button->color(FL_BLACK);   
            dec_button->labelcolor(FL_GREEN); /* << */
            dec_button->redraw();

            hex_button->color(FL_BLACK);
            hex_button->labelcolor(FL_WHITE);
            hex_button->redraw();

            oct_button->color(FL_BLACK);
            oct_button->labelcolor(FL_WHITE);
            oct_button->redraw();

            bin_button->color(FL_BLACK);
            bin_button->labelcolor(FL_WHITE);
            bin_button->redraw();

            break;
        }

        case 16:
        {

            activateDeactivateButtons(HEX_BUTTONS,ACTIVATE);
            activateDeactivateButtons(NUM_BUTTONS,ACTIVATE);

            hex_button->color(FL_BLACK);  
            hex_button->labelcolor(FL_GREEN); /* << */
            hex_button->redraw();

            dec_button->color(FL_BLACK);
            dec_button->labelcolor(FL_WHITE);
            dec_button->redraw();

            oct_button->color(FL_BLACK);
            oct_button->labelcolor(FL_WHITE);
            oct_button->redraw();

            bin_button->color(FL_BLACK);
            bin_button->labelcolor(FL_WHITE);
            bin_button->redraw();


            break;
        }

          case 8:
          {
            activateDeactivateButtons(HEX_BUTTONS,DEACTIVATE);
            activateDeactivateButtons(NUM_BUTTONS,ACTIVATE);
            eight_button->deactivate();
            nine_button->deactivate();

            hex_button->color(FL_BLACK);
            hex_button->labelcolor(FL_WHITE);
            hex_button->redraw();

            dec_button->color(FL_BLACK);
            dec_button->labelcolor(FL_WHITE);
            dec_button->redraw();

            oct_button->color(FL_BLACK);   
            oct_button->labelcolor(FL_GREEN); /* << */
            oct_button->redraw();

            bin_button->color(FL_BLACK);
            bin_button->labelcolor(FL_WHITE);
            bin_button->redraw();

            hexButtons(0);
            break;
          }

          case 2:
          {
            activateDeactivateButtons(HEX_BUTTONS,DEACTIVATE);
            activateDeactivateButtons(NUM_BUTTONS,DEACTIVATE);

            hex_button->color(FL_BLACK);
            hex_button->labelcolor(FL_WHITE);
            hex_button->redraw();

            dec_button->color(FL_BLACK);
            dec_button->labelcolor(FL_WHITE);
            dec_button->redraw();

            oct_button->color(FL_BLACK);
            oct_button->labelcolor(FL_WHITE);
            oct_button->redraw();

            bin_button->color(FL_BLACK);    
            bin_button->labelcolor(FL_GREEN); /* << */
            bin_button->redraw();
            break;
          }
      }

}


/*
**  modeButtonsCb()
**      callback routine for HEX, DEC and OCT button
**
**  Parameters:
**      int base
**
**  Return Values:
**      none
**
**  Limitations and Comments:
**      uses global s_value and s_accum as the numbers to display
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   May-06-2001     first cut
*/
void modeButtonsCb(int base)
{
    g_base=base;

    highlishtModeButton(base);
    if (s_last_op == OPR_ASGN)
        displayNumber(s_accum,base);
    else
        displayNumber(s_value,g_base);
}


/*
**  specButtonCb()
**      call back routine for S/U, CE, CD and CA
**
**  Parameters:
**      int b 
**
**  Return Values:
**      none
**
**  Limitations and Comments:
**      S/U         - signed/unsigned operation
**      CE - CTRL+E - erase
**      CD - CTRL+D - delete
**      CA - CTRL+A - clear all
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   May-06-2001     first cut
*/
void specButtonCb(int b)
{
    switch (b)
    {
        case OPR_CLRE: /* CE */
        {
            s_value=0;
            displayNumber(s_value,g_base);
            break;
        }

        case OPR_CLRD: /* CD */
        {
            if (s_last_op == OPR_ASGN)
                break;
            s_value = (unsigned) s_value / g_base;
            displayNumber(s_value,g_base);
            break;
        }

        case OPR_CLRA: /* CA */
        {
            s_value=0;
            s_accum=0;
            displayNumber(s_value,g_base);
            s_last_op=OPR_ADD;
            break;
        }

        case OPR_UNS:
        {
            const char 
                *lab;
            s_unsigned = !s_unsigned;
            lab=s_unsigned ? "U" : "S"; /* XXX */
            setUnsigned(s_unsigned);
            u_button->label(lab);
            u_button->redraw();
            if (s_unsigned)
                u_button->shortcut(FL_SHIFT+'s');
            else
                u_button->shortcut(FL_SHIFT+'u');
            displayNumber(s_value,g_base);
            break;
        }
    }
}


/*
**  displayNumber()
**      display a number as base 2, 10,16
**
**  Parameters:
**      unsigned int    num
**      int             base
**
**  Return Values:
**      none
**
**  Limitations and Comments:
**      text_disp is the global widget to display the digits.
**      right now there's a refresh problem I noticed if the window is
**      obscured or folded.
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   May-06-2001     first cut
*/
void displayNumber(unsigned int num,int base)
{
    static char
        *s_label=NULL;

    char
        dotbuf[128],
        buf[128];

    memset(dotbuf,0,sizeof(dotbuf));
    switch (base)
    {
        case 2:
        {
            baseSprintf(buf,"%032b",num);
            dotize(buf,dotbuf,4);
            break;
        }

        case 8:
        {
            baseSprintf(buf,"%32o",num);
            dotize(buf,dotbuf,3);
            break;
        }

        case 10:
        {
            baseSprintf(buf,"%32d",num);
            dotize(buf,dotbuf,3);
            break;
        }

        case 16:
        {
            baseSprintf(buf,"%32x",num);
            dotize(buf,dotbuf,4);
            break;
        }
    }

    /*
    ** In Windows NT, if we set the label with dotbuf, it goes to an
    ** infinite loop. don't know why at this time.
    ** muquit@muquit.com May-08-2001 
    */
    if (s_label != NULL)
        (void) free((char *) s_label);
    s_label=strdup(dotbuf);
    if (s_label == NULL)
    {
        (void) fprintf(stderr,"Memory allocation problem with s_label\n");
        return;
    }
    text_disp->label(s_label);
    text_disp->redraw();
}


/*
**  operCb()
**      callback routine for + - * / etc.
**
**  Parameters:
**      int xoer    - the int value passed when the button is pressed
**
**  Return Values:
**      none
**
**  Limitations and Comments:
**      desinged adapted from basecalc, comes with O'Reilly X lib book.
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   May-06-2001     first cut
*/
void operCb(int xoper)
{
    char
        buf2[128],
        buf[128];

    int
        oper;

    s_reset=0;

    oper=s_last_op;
    s_last_op=xoper;

    switch (s_last_op)
    {
        case OPR_NOT:
        {
            s_value = ~s_value;
            if ((s_last_op=oper) == OPR_ASGN)
                s_accum=s_value;

            displayNumber(s_value,g_base);
            return;
        }
    }

    switch (oper)
    {
        case OPR_ADD:
        {
            if (s_unsigned)
                s_accum = (unsigned) s_accum + (unsigned) s_value;
            else
                s_accum += s_value;
            break;
        }

        case OPR_SUB:
        {
            if (s_unsigned)
                s_accum = (unsigned) s_accum - (unsigned) s_value;
            else
                s_accum -= s_value;
            break;
        }

        case OPR_MUL:
        {
            if (s_unsigned)
                s_accum = (unsigned) s_accum * (unsigned) s_value;
            else
                s_accum *= s_value;
            break;
        }

        case OPR_DIV:
        {
            if (s_value == 0)
                break;

            if (s_unsigned)
                s_accum = (unsigned) s_accum / (unsigned) s_value;
            else
                s_accum /= s_value;
            break;
        }

        case OPR_MOD:
        {
            if (s_value == 0)
                break;

            if (s_unsigned)
                s_accum = (unsigned) s_accum % (unsigned) s_value;
            else
                s_accum %= s_value;
            break;
        }

        case OPR_OR:
        {
            s_accum |= s_value;
            break;
        }
        case OPR_AND:
        {
            s_accum &= s_value;
            break;
        }

        case OPR_SHR:
        {
            if (s_unsigned)
                s_accum = (unsigned) s_accum >> (unsigned) s_value;
            else
                s_accum >>= s_value;
            break;
        }
        case OPR_SHL:
        {
            if (s_unsigned)
                s_accum = (unsigned) s_accum << (unsigned) s_value;
            else
                s_accum <<= s_value;
            break;
        }

        case OPR_XOR:
        {
            s_accum ^= s_value;
            break;
        }

        case OPR_ASGN:
        {
            break;
        }
    }

    if (s_last_op == OPR_ASGN)
    {
        s_reset=1;
        s_value=s_accum;
        displayNumber(s_accum,g_base);
        return;
    }
    s_value=0;
    displayNumber(s_accum,g_base);
}


/*
**  numButtonCb()
**      callback routine when the number buttons are pressed.
**
**  Parameters:
**     int n - the number pressed
**
**  Return Values:
**      none
**
**  Limitations and Comments:
**      fills the s_value static in this module file. adapted from
**      basecalc
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   May-06-2001     first cut
*/
void numButtonCb(int n)
{
    int
        ln;

    unsigned int
        temp;

    if (s_reset == 1)
    {
        s_reset=0;
        s_accum=0;
        s_value=0;
        s_last_op=OPR_ADD;
    }

    if (s_unsigned)
        temp=(unsigned) s_value * (unsigned) g_base + n;
    else
        temp=s_value * g_base + n;

#if 0
    if ((unsigned) temp / g_base != (unsigned) s_value) /* overflow */
    {
        s_reset=0;
        s_value=0;
        s_accum=0;
        displayNumber(s_value,g_base);
        return;
    }
#endif /* if 0 */

    s_value=temp;
    displayNumber(s_value,g_base);
}


/*
**  backSpaceCb()
**      The Backspace button callback routine
**
**  Parameters:
**      none
**
**  Return Values:
**      none
**
**  Limitations and Comments:
**      calls specButtonCb()
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   May-06-2001     first cut
*/
void backSpaceCb(void)
{
    specButtonCb(OPR_CLRD);
}

void refreshCb(void)
{
    if (s_last_op == OPR_ASGN)
        displayNumber(s_accum,g_base);
    else
        displayNumber(s_value,g_base);
}
