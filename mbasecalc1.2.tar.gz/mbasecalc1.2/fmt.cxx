#include "fmt.h"

static int Unsigned=1;

/*
 * Print a number n in base b into string cp.
 * Minimum field width = fw, pad character = pad
 */

/*
** this routine is called from the callback funcion of "U" button in
** callbacks.h. The value of Unsigned is set.
*/
void setUnsigned(unsigned int su)
{
    Unsigned=su;
}


static char *mutilsReverseString(char *str)
{
    char
        *p1,
        *p2;

    if (! str || ! *str)
        return str;

    for (p1=str,p2 =str+strlen(str)-1; p2 > p1; ++p1, --p2)
    {
        *p1 ^= *p2;
        *p2 ^= *p1;
        *p1 ^= *p2;
    }
    return (str);
}

void dotize(char *src,char *dst,int m)
{
    int
        i,
        j;

    char
        *dp,
        *sp;

    mutilsReverseString(src);

    dp=dst;
    sp=src;
    for (i=0; i < strlen(src); i++)
    {
        j=i;
        *dp++ = *sp++;
        if (++j % m == 0)
        {
            *dp++=' ';
            *dp++='.';
            *dp++=' ';
        }
    }
    *dp='\0';
    mutilsReverseString(dst);
}


/*
**  printInBase()
**      print a number n in base b into string cp
**
**  Parameters:
**
**
**  Return Values:
**
**
**  Limitations and Comments:
**  taken from basecalc from O'Reilly X11 book sample code
**
**  Development History:
**      who                  when           why
**      muquit@muquit.com   Apr-23-2001     first cut
*/
static void printInBase (char *cp,long n,int b,int fw,int pad,int sign)
{
    register int
        i,
        nd,
        c;

    int
        flag;

    int
        plmax;

    char
        d[33];

    c = 1;
    if (sign)
        flag = n < 0;
    else
        flag = 0;
    if (flag)
        n = (-n);
    if (b == 2)
        plmax = 32;
    else if (b == 8)
        plmax = 11;
    else if (b == 10)
        plmax = 10;
    else if (b == 16)
        plmax = 8;
    if (b == 10) {
        if (flag == 0)
            sign = 0;
        flag = 0;
    }
    for (i = 0; i < plmax; i++)
    {
        if (flag == 0)
            nd = (unsigned)n % b;
        else
            nd = n % b;
        if (flag)
        {
            nd = (b - 1) - nd + c;
            if (nd >= b)
            {
                nd -= b;
                c = 1;
            } else
                c = 0;
        }
        d[i] = nd;
        if (flag == 0)
            n = (unsigned)n / b;
        else
            n = n / b;
        if ((n == 0) && (flag == 0))
            break;
    }
    if (i == plmax)
        i--;
    if (sign)
    {
        fw--;
        if (pad == '0')
            *cp++ = '-';
    }
    if (fw > i + 1)
    {
        for (fw -= i + 1; fw > 0; fw--)
            *cp++ = pad;
    }
    if (sign && pad != '0')
        *cp++ = '-';
    for (; i >= 0; i--)
        *cp++ = "0123456789ABCDEF"[d[i]];
    *cp = '\0';
}


void baseSprintf(char *cp,char *fmt,unsigned int x1)
{
    register int c, b, sign;
    register char *s;
    register unsigned short fw;
    char pad;

    while ((c = *fmt++) != '%') {
        if (c == '\0') {
            *cp = c;
            return;   /* to displayVal */
        }
        *cp++ = c;
    }
    c = *fmt++;
    if (c == '0') {
        pad = '0';
        c = *fmt++;
    } else
        pad = ' ';

    /*
     * Calculate minimum field width
     */
    fw = 0;
    while (c >= '0' && c <= '9') {
        fw = fw * 10 + (c - '0');
        c = *fmt++;
    }
    sign = 0;
    switch (c) {
    case 'x':
        b = 16;
        break;
    case 'd':
        if (!Unsigned)
            sign = 1;
        /*  falls through into 'u' case */
    case 'u':
        b = 10;
        break;
    case 'o':
        b = 8;
        break;
    case 'b':
        b = 2;
        break;
    default:
        /*
         * Unknown format
         */
        b = 0;
        break;
    }
    if (b)
        printInBase (cp, x1, b, fw, pad, sign);
}

#ifdef TEST2
int main(int argc,char **argv)
{
    unsigned int
        n;

    char
        *p,
        buf[BUFSIZ];

    if (argc != 2)
        exit(1);

    n=atoi(argv[1]);

    p=Sprintf(buf,"%32d",n);
    (void) fprintf(stderr," buf=\"%s\"\n",buf);
    p=Sprintf(buf,"%32x",n);
    (void) fprintf(stderr," buf=\"%s\"\n",buf);
    p=Sprintf(buf,"%32o",n);
    (void) fprintf(stderr," buf=\"%s\"\n",buf);
    p=Sprintf(buf,"%032b",n);
    (void) fprintf(stderr," buf=\"%s\"\n",buf);
    return (0);
}

#endif /* TEST */


