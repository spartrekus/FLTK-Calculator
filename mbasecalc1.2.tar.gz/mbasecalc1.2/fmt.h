#ifndef FMT_H
#define FMT_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h> /* atoi*/

void baseSprintf(char *cp,char *fmt,unsigned int x1);
void dotize(char *src,char *dst,int m);
void hexButtons(int w);
void setUnsigned(unsigned int su);


#endif /* ! FMT_H */
