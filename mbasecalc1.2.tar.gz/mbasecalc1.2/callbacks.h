#ifndef CBS_H
#define CBS_H

/* callback related stuff*/

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Menu_Item.H>

#include <stdio.h>
#include <string.h>

#define MBASECALC_VERSION   "1.1"


#define HEX_BUTTONS         1
#define NUM_BUTTONS         2

/* copied blatantly from basecalc */
#define OPR_ADD     1
#define OPR_SUB     2
#define OPR_MUL     3
#define OPR_DIV     4
#define OPR_MOD     5
#define OPR_OR      6
#define OPR_AND     7
#define OPR_XOR     8
#define OPR_SHL     9
#define OPR_SHR     10
#define OPR_CLRE    11
#define OPR_CLRD    12
#define OPR_CLRA    13
#define OPR_ASGN    14
#define OPR_NEG     15
#define OPR_NOT     16
#define OPR_UNS     17



#define ACTIVATE            1
#define DEACTIVATE          2


#define SELECTED_BG_RED    113
#define SELECTED_BG_GREEN  198
#define SELECTED_BG_BLUE   113

#define SELECTED_FG_RED    0
#define SELECTED_FG_GREEN  145
#define SELECTED_FG_BLUE   0


void modeButtonsCb(int base);
void specButtonCb(int b);
void makeColors(void);
void reDisplayDigits(int base);
void activateDeactivateButtons(int buttons,int do_what);
void operCb(int oper);
void backSpaceCb(void);
void numButtonCb(int n);
void displayNumber(unsigned int num,int base);
void refreshCb(void);
void signedUnsignedCb(int n);


#endif /* ! CBS_H */
